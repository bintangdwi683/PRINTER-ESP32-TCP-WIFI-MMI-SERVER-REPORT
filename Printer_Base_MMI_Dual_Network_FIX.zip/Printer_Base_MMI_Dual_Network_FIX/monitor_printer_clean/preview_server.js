// Local dashboard preview. It simulates the ESP32 API; it is not firmware.
const http = require('http');
const fs = require('fs');
const path = require('path');

const header = fs.readFileSync(path.join(__dirname, 'dashboard_page.h'), 'utf8');
const match = header.match(/R"HTML\(([\s\S]*?)\)HTML"/);
if (!match) throw new Error('DASHBOARD_HTML tidak ditemukan.');
const startedAt = Date.now();
let logs = ['[00:00:00] Preview dashboard lokal dimulai', '[00:00:01] Wi-Fi terhubung, IP 192.168.1.20', '[00:00:02] LAN siap, IP 192.168.1.21'];

function status() {
  const uptime = Math.floor((Date.now() - startedAt) / 1000);
  const bandwidthBps = 40 + Math.round(Math.random() * 180);
  return { activeInterface: 'Wi-Fi + LAN', activeIp: '192.168.1.20 / 192.168.1.21', wifiConnected: true, wifiStandby: false, wifiIp: '192.168.1.20', lanConnected: true, lanIp: '192.168.1.21', queueCount: 0, printCount: 24, paperAvailable: true, lastPrintState: 'Selesai', lastPrintError: '', lastRecipeName: 'Semen', lastTarget: '1000', lastActual: '1000', hourlyPrints: [0,0,0,0,0,0,0,0,2,3,1,4,0,2,5,3,1,2,1,0,0,0,0,0], storageReady: true, uptime, bandwidthBps, peakBandwidthBps: 220, totalMqttBytes: 18432 + uptime * bandwidthBps, settings: { ssid: 'MMI', wifiIp: '192.168.1.20', lanIp: '192.168.1.21', gateway: '192.168.1.1', subnet: '255.255.255.0' } };
}

http.createServer((req, res) => {
  if (req.url === '/') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(match[1]); }
  if (req.url === '/api/status') { res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); return res.end(JSON.stringify(status())); }
  if (req.url === '/api/logs' && req.method === 'GET') { res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end(logs.join('\n')); }
  if (req.url === '/api/logs' && req.method === 'DELETE') { logs = ['[preview] Log dashboard dibersihkan']; res.writeHead(200); return res.end('OK'); }
  if (req.url === '/api/settings' && req.method === 'POST') { res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Tersimpan (mode preview; ESP32 tidak direstart).'); }
  if (req.url === '/prints.csv') { res.writeHead(200, { 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename=printer-base-mmi.csv' }); return res.end('NoSpk,Jam,Tanggal,NoBatch,Nama,Target,Actual,Status\nSPK-001,08:30,2026-09-06,B-001,Semen,1000,1000,Oke\nSPK-002,09:10,2026-09-06,B-002,Kapur,1000,930,Kurang\nSPK-003,10:15,2026-09-06,B-003,Pasir Kasar,1000,1060,Lebih\nSPK-004,11:20,2026-09-06,B-004,Pasir Halus,1000,1005,Oke\n'); }
  res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found');
}).listen(8080, '127.0.0.1', () => console.log('Preview: http://127.0.0.1:8080'));
