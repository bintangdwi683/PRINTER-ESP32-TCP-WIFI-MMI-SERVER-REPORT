9m#include <ArduinoJson.h>
#include <esp_arduino_version.h>

#if ESP_ARDUINO_VERSION_MAJOR < 3
#error "Kode W5500 ini membutuhkan ESP32 by Espressif Systems versi 3.x atau lebih baru. Perbarui melalui Arduino Boards Manager."
#endif

#include <Network.h>
#include <ETH.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <SPI.h>
#include <WebServer.h>
#include <WiFi.h>
#include <time.h>
#include "sMQTTBroker.h"
#include "dashboard_page.h"
#include "print_types.h"

namespace Config {
constexpr char WIFI_SSID[] = "MMI";
constexpr char WIFI_PASSWORD[] = "MMIindihome";

constexpr uint8_t WIFI_LED_PIN = 2;
constexpr uint8_t PRINTER_RX_PIN = 16;
constexpr uint8_t PRINTER_TX_PIN = 17;
// Sambungkan ke output paper-out printer bila tersedia; -1 menonaktifkan pin.
constexpr int8_t PRINTER_PAPER_OUT_PIN = -1;
constexpr bool PAPER_OUT_ACTIVE_HIGH = true;
constexpr uint8_t W5500_SCK_PIN = 12;
constexpr uint8_t W5500_MISO_PIN = 13;
constexpr uint8_t W5500_MOSI_PIN = 18;
constexpr uint8_t W5500_CS_PIN = 15;
constexpr uint8_t W5500_IRQ_PIN = 4;
constexpr uint8_t W5500_RESET_PIN = 14;
constexpr int8_t W5500_PHY_ADDRESS = 1;

constexpr uint32_t SERIAL_BAUD_RATE = 115200;
constexpr uint32_t PRINTER_BAUD_RATE = 19200;
constexpr uint16_t MQTT_PORT = 1883;

constexpr size_t PRINT_QUEUE_SIZE = 20;
constexpr size_t JSON_DOCUMENT_SIZE = 1024;
constexpr size_t DEDUPLICATION_CACHE_SIZE = 20;
constexpr double TARGET_TOLERANCE = 50.0;

constexpr unsigned long WIFI_CONNECT_TIMEOUT_MS = 30000;
constexpr unsigned long WIFI_RETRY_INTERVAL_MS = 10000;
constexpr unsigned long WIFI_LED_INTERVAL_MS = 500;
constexpr unsigned long PRINT_RETRY_INTERVAL_MS = 500;
constexpr unsigned long DUPLICATE_WINDOW_MS = 60000;
constexpr unsigned long PRINTER_STATUS_TIMEOUT_MS = 250;
constexpr size_t LOG_CAPACITY = 80;
}  // namespace Config

HardwareSerial printerSerial(2);

struct DeviceSettings {
  String ssid = Config::WIFI_SSID;
  String password = Config::WIFI_PASSWORD;
  IPAddress wifiIp{192, 168, 1, 20};
  IPAddress lanIp{192, 168, 1, 21};
  IPAddress gateway{192, 168, 1, 1};
  IPAddress subnet{255, 255, 255, 0};
  IPAddress primaryDns{8, 8, 8, 8};
  IPAddress secondaryDns{8, 8, 4, 4};
} settings;

Preferences preferences;
WebServer webServer(80);
bool storageReady = false;
uint32_t printCount = 0;
uint32_t completedPrintsThisHour = 0;
uint32_t hourlyPrints[24] = {};
String lastPrintState = "Menunggu";
String lastPrintError;
String lastRecipeName = "—";
String lastTarget = "—";
String lastActual = "—";
uint64_t totalMqttBytes = 0;
uint64_t lastBandwidthBytes = 0;
float currentBandwidthBps = 0.0F;
float peakBandwidthBps = 0.0F;
unsigned long lastBandwidthSampleAt = 0;
String deviceLogs[Config::LOG_CAPACITY];
size_t logHead = 0;
size_t logCount = 0;

String printQueue[Config::PRINT_QUEUE_SIZE];
size_t queueHead = 0;
size_t queueTail = 0;
size_t queueCount = 0;

uint32_t recentPayloadHashes[Config::DEDUPLICATION_CACHE_SIZE] = {};
unsigned long recentPayloadTimes[Config::DEDUPLICATION_CACHE_SIZE] = {};
size_t deduplicationIndex = 0;

unsigned long lastWifiBlinkAt = 0;
unsigned long lastWifiRetryAt = 0;
unsigned long lastPrintCheckAt = 0;
bool wifiLedState = false;
volatile bool lanHasIp = false;
volatile bool lanLinkConnected = false;
bool wifiStarted = false;
bool lanModeActive = false;

bool paperAvailable() {
  if (Config::PRINTER_PAPER_OUT_PIN < 0) return true;
  const bool paperOut = digitalRead(Config::PRINTER_PAPER_OUT_PIN) ==
                        (Config::PAPER_OUT_ACTIVE_HIGH ? HIGH : LOW);
  return !paperOut;
}

void addLog(const char *format, ...) {
  char message[256];
  va_list args;
  va_start(args, format);
  vsnprintf(message, sizeof(message), format, args);
  va_end(args);

  Serial.println(message);
  const unsigned long seconds = millis() / 1000;
  char line[300];
  snprintf(line, sizeof(line), "[%02lu:%02lu:%02lu] %s",
           seconds / 3600, (seconds / 60) % 60, seconds % 60, message);
  deviceLogs[logHead] = line;
  logHead = (logHead + 1) % Config::LOG_CAPACITY;
  if (logCount < Config::LOG_CAPACITY) {
    ++logCount;
  }
}

bool parseIp(const String &value, IPAddress &result) {
  IPAddress parsed;
  if (!parsed.fromString(value)) {
    return false;
  }
  result = parsed;
  return true;
}

void loadSettings() {
  preferences.begin("printer-mmi", false);
  settings.ssid = preferences.getString("ssid", Config::WIFI_SSID);
  settings.password = preferences.getString("wifi-pass", Config::WIFI_PASSWORD);
  parseIp(preferences.getString("wifi-ip", "192.168.1.20"), settings.wifiIp);
  parseIp(preferences.getString("lan-ip", "192.168.1.21"), settings.lanIp);
  parseIp(preferences.getString("gateway", "192.168.1.1"), settings.gateway);
  parseIp(preferences.getString("subnet", "255.255.255.0"), settings.subnet);

  // Migrasi konfigurasi active-standby lama ke dual-interface aktif.
  if (settings.wifiIp == settings.lanIp) {
    const uint8_t lastOctet = settings.wifiIp[3];
    settings.lanIp = IPAddress(settings.wifiIp[0], settings.wifiIp[1],
                               settings.wifiIp[2],
                               lastOctet < 254 ? lastOctet + 1 : lastOctet - 1);
    preferences.putString("lan-ip", settings.lanIp.toString());
    addLog("IP LAN otomatis dipisahkan menjadi %s",
           settings.lanIp.toString().c_str());
  }
}

String csvEscape(const String &value) {
  String escaped = value;
  escaped.replace("\"", "\"\"");
  return '"' + escaped + '"';
}

void initializeStorage() {
  storageReady = LittleFS.begin(true);
  if (!storageReady) {
    addLog("LittleFS gagal dimulai");
    return;
  }

  if (!LittleFS.exists("/prints.csv")) {
    File file = LittleFS.open("/prints.csv", FILE_WRITE);
    if (file) {
      file.println("NoSpk,Jam,Tanggal,NoBatch,Nama,Target,Actual,Status");
      file.close();
    }
  }

  File file = LittleFS.open("/prints.csv", FILE_READ);
  printCount = 0;
  if (file) {
    bool firstLine = true;
    while (file.available()) {
      file.readStringUntil('\n');
      if (firstLine) firstLine = false;
      else ++printCount;
    }
    file.close();
  }
  addLog("Penyimpanan siap, %lu data cetak", printCount);
}

void appendPrintCsv(JsonDocument &document, const char *status) {
  if (!storageReady) return;

  File file = LittleFS.open("/prints.csv", FILE_APPEND);
  if (!file) {
    addLog("Gagal membuka CSV untuk menyimpan data");
    return;
  }

  const char *keys[] = {"NoSpk", "Jam", "Tanggal", "NoBatch", "Nama",
                        "Target", "Actual"};
  for (const char *key : keys) {
    String value = document[key].as<String>();
    file.print(csvEscape(value));
    file.print(',');
  }
  file.println(csvEscape(status));
  file.close();
  ++printCount;
  addLog("Data cetak tersimpan ke CSV (#%lu)", printCount);
}

uint32_t hashPayload(const String &payload) {
  // FNV-1a 32-bit: ringan dan cukup untuk mendeteksi kiriman ulang MQTT.
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < payload.length(); ++i) {
    hash ^= static_cast<uint8_t>(payload[i]);
    hash *= 16777619UL;
  }
  return hash;
}

bool isDuplicatePayload(const String &payload, unsigned long now) {
  const uint32_t hash = hashPayload(payload);

  for (size_t i = 0; i < Config::DEDUPLICATION_CACHE_SIZE; ++i) {
    if (recentPayloadHashes[i] == hash &&
        now - recentPayloadTimes[i] <= Config::DUPLICATE_WINDOW_MS) {
      return true;
    }
  }

  return false;
}

void rememberPayload(const String &payload, unsigned long now) {
  const uint32_t hash = hashPayload(payload);
  recentPayloadHashes[deduplicationIndex] = hash;
  recentPayloadTimes[deduplicationIndex] = now;
  deduplicationIndex =
      (deduplicationIndex + 1) % Config::DEDUPLICATION_CACHE_SIZE;
}

bool enqueue(const String &payload) {
  if (queueCount >= Config::PRINT_QUEUE_SIZE) {
    addLog("Antrean penuh, data MQTT diabaikan");
    return false;
  }

  printQueue[queueTail] = payload;
  queueTail = (queueTail + 1) % Config::PRINT_QUEUE_SIZE;
  ++queueCount;

  addLog("Data masuk antrean (%u/%u)",
         static_cast<unsigned int>(queueCount),
         static_cast<unsigned int>(Config::PRINT_QUEUE_SIZE));
  return true;
}

bool queueAvailable() {
  return queueCount > 0;
}

String dequeue() {
  if (!queueAvailable()) {
    return String();
  }

  String payload = printQueue[queueHead];
  printQueue[queueHead] = String();
  queueHead = (queueHead + 1) % Config::PRINT_QUEUE_SIZE;
  --queueCount;
  return payload;
}

const String &peekQueue() {
  static const String empty;
  return queueAvailable() ? printQueue[queueHead] : empty;
}

void discardQueueHead() {
  if (!queueAvailable()) return;
  printQueue[queueHead] = String();
  queueHead = (queueHead + 1) % Config::PRINT_QUEUE_SIZE;
  --queueCount;
}

namespace PrinterCommand {
void writeCommand(uint8_t command, uint8_t value) {
  printerSerial.write(0x1B);
  printerSerial.write(command);
  printerSerial.write(value);
}

void initialize() {
  printerSerial.write(0x1B);
  printerSerial.write(0x40);
  delay(100);
}

void setAlignment(uint8_t alignment) {
  writeCommand(0x61, alignment);
}

void setBold(bool enabled) {
  writeCommand(0x45, enabled ? 0x01 : 0x00);
}

void printField(const __FlashStringHelper *label, const String &value) {
  printerSerial.print(label);
  printerSerial.print(value);
  printerSerial.print(F("\r\n"));
}
}  // namespace PrinterCommand

PrintResult printRecipe(const String &payload) {
  DynamicJsonDocument document(Config::JSON_DOCUMENT_SIZE);
  const DeserializationError error = deserializeJson(document, payload);

  if (error) {
    addLog("JSON tidak valid: %s", error.c_str());
    lastPrintState = "JSON tidak valid";
    lastPrintError = error.c_str();
    return PrintResult::Invalid;
  }

  const char *required[] = {"NoSpk", "Jam", "Tanggal", "NoBatch", "Nama",
                            "Target", "Actual"};
  for (const char *key : required) {
    JsonVariant value = document[key];
    // MQTT sering mengirim Target/Actual sebagai number, bukan string.
    if (value.isNull() || (value.is<const char *>() && value.as<String>().isEmpty())) {
      addLog("JSON ditolak: field %s kosong", key);
      lastPrintState = "JSON tidak lengkap";
      lastPrintError = key;
      return PrintResult::Invalid;
    }
  }
  if (!paperAvailable()) {
    addLog("Kertas habis, job tetap di antrean");
    lastPrintState = "Menunggu kertas";
    lastPrintError = "Paper out";
    return PrintResult::RetryLater;
  }

  const double target = document["Target"].as<double>();
  const double actual = document["Actual"].as<double>();
  lastRecipeName = document["Nama"].as<String>();
  lastTarget = document["Target"].as<String>();
  lastActual = document["Actual"].as<String>();
  const double lowerLimit = target - Config::TARGET_TOLERANCE;
  const double upperLimit = target + Config::TARGET_TOLERANCE;

  const char *status;
  if (actual < lowerLimit) {
    status = "Kurang";
  } else if (actual > upperLimit) {
    status = "Lebih";
  } else {
    status = "Oke";
  }

  addLog("Mulai cetak | Range %.2f-%.2f | Actual %.2f | %s",
         lowerLimit, upperLimit, actual, status);

  PrinterCommand::initialize();
  PrinterCommand::setAlignment(0x01);
  PrinterCommand::setBold(true);
  printerSerial.print(F("RECIPE BATCH\r\n"));
  PrinterCommand::setBold(false);
  PrinterCommand::setAlignment(0x00);

  printerSerial.print(F("============================\r\n"));
  PrinterCommand::printField(F("No SPK   : "), document["NoSpk"].as<String>());
  PrinterCommand::printField(F("Jam      : "), document["Jam"].as<String>());
  PrinterCommand::printField(F("Tanggal  : "), document["Tanggal"].as<String>());
  PrinterCommand::printField(F("No Batch : "), document["NoBatch"].as<String>());
  PrinterCommand::printField(F("Nama     : "), document["Nama"].as<String>());
  PrinterCommand::printField(F("Target   : "), document["Target"].as<String>());
  PrinterCommand::printField(F("Actual   : "), document["Actual"].as<String>());
  PrinterCommand::printField(F("Status   : "), String(status));
  printerSerial.print(F("============================\r\n\r\n"));
  printerSerial.flush();

  appendPrintCsv(document, status);
  const time_t now = time(nullptr);
  const tm *local = localtime(&now);
  if (local != nullptr) ++hourlyPrints[local->tm_hour];
  ++completedPrintsThisHour;
  lastPrintState = "Selesai";
  lastPrintError = "";
  addLog("Cetak berhasil");
  return PrintResult::Printed;
}

class PrinterBroker : public sMQTTBroker {
 public:
  bool onEvent(sMQTTEvent *event) override {
    if (event == nullptr || event->Type() != Public_sMQTTEventType) {
      return true;
    }

    auto *clientEvent = static_cast<sMQTTPublicClientEvent *>(event);
    const String payload = clientEvent->Payload().c_str();
    totalMqttBytes += payload.length();

    addLog("Data MQTT diterima (%u byte)", payload.length());

    if (isDuplicatePayload(payload, millis())) {
      addLog("Duplikat terdeteksi, cetak dibatalkan");
      return true;
    }

    if (enqueue(payload)) {
      rememberPayload(payload, millis());
    }
    return true;
  }
};

PrinterBroker broker;

void onNetworkEvent(arduino_event_id_t event, arduino_event_info_t info) {
  (void)info;

  switch (event) {
    case ARDUINO_EVENT_ETH_START:
      ETH.setHostname("esp32-printer-lan");
      addLog("W5500 dimulai");
      break;

    case ARDUINO_EVENT_ETH_CONNECTED:
      lanLinkConnected = true;
      addLog("Kabel LAN terhubung");
      break;

    case ARDUINO_EVENT_ETH_GOT_IP:
      lanHasIp = true;
      addLog("LAN siap, IP %s", ETH.localIP().toString().c_str());
      break;

    case ARDUINO_EVENT_ETH_LOST_IP:
    case ARDUINO_EVENT_ETH_DISCONNECTED:
    case ARDUINO_EVENT_ETH_STOP:
      lanHasIp = false;
      lanLinkConnected = false;
      addLog("LAN tidak tersedia, Wi-Fi menjadi cadangan");
      break;

    default:
      break;
  }
}

void initializeEthernet() {
  Network.onEvent(onNetworkEvent);
  SPI.begin(Config::W5500_SCK_PIN, Config::W5500_MISO_PIN,
            Config::W5500_MOSI_PIN, Config::W5500_CS_PIN);

  const bool started = ETH.begin(
      ETH_PHY_W5500, Config::W5500_PHY_ADDRESS, Config::W5500_CS_PIN,
      Config::W5500_IRQ_PIN, Config::W5500_RESET_PIN, SPI);

  if (!started) {
    addLog("W5500 gagal dimulai, periksa wiring dan pin");
    return;
  }

  if (!ETH.config(settings.lanIp, settings.gateway, settings.subnet,
                  settings.primaryDns, settings.secondaryDns)) {
    addLog("Gagal mengatur IP statis W5500");
  }
}

void connectWifi() {
  Serial.print(F("Menghubungkan Wi-Fi"));
  wifiStarted = true;
  WiFi.begin(settings.ssid.c_str(), settings.password.c_str());

  const unsigned long startedAt = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - startedAt < Config::WIFI_CONNECT_TIMEOUT_MS) {
    delay(500);
    Serial.print('.');
  }

  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    addLog("Wi-Fi terhubung, IP %s", WiFi.localIP().toString().c_str());
  } else {
    addLog("Wi-Fi belum terhubung, percobaan dilanjutkan");
  }
}

void updateWifiConnection(unsigned long now) {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  if (now - lastWifiRetryAt >= Config::WIFI_RETRY_INTERVAL_MS) {
    lastWifiRetryAt = now;
    if (!wifiStarted) {
      addLog("Mengaktifkan Wi-Fi cadangan");
      wifiStarted = true;
      WiFi.begin(settings.ssid.c_str(), settings.password.c_str());
    } else {
      addLog("Mencoba menghubungkan ulang Wi-Fi");
      WiFi.reconnect();
    }
  }
}

void updateWifiLed(unsigned long now) {
  if (WiFi.status() != WL_CONNECTED && !lanHasIp) {
    wifiLedState = false;
    digitalWrite(Config::WIFI_LED_PIN, LOW);
    return;
  }

  if (now - lastWifiBlinkAt >= Config::WIFI_LED_INTERVAL_MS) {
    lastWifiBlinkAt = now;
    wifiLedState = !wifiLedState;
    digitalWrite(Config::WIFI_LED_PIN, wifiLedState);
  }
}

void processPrintQueue(unsigned long now) {
  if (!queueAvailable() ||
      now - lastPrintCheckAt < Config::PRINT_RETRY_INTERVAL_MS) {
    return;
  }

  lastPrintCheckAt = now;
  // Jangan keluarkan job sebelum hasilnya pasti: job retry tetap di head antrean.
  const PrintResult result = printRecipe(peekQueue());
  if (result == PrintResult::Printed || result == PrintResult::Invalid) {
    discardQueueHead();
  }
}

void updateBandwidth(unsigned long now) {
  const unsigned long elapsed = now - lastBandwidthSampleAt;
  if (elapsed < 1000) return;

  const uint64_t bytesNow = totalMqttBytes;
  const uint64_t bytesDelta = bytesNow - lastBandwidthBytes;
  currentBandwidthBps = static_cast<float>(bytesDelta) * 1000.0F /
                        static_cast<float>(elapsed);
  if (currentBandwidthBps > peakBandwidthBps) {
    peakBandwidthBps = currentBandwidthBps;
  }
  lastBandwidthBytes = bytesNow;
  lastBandwidthSampleAt = now;
}

void sendStatusJson() {
  DynamicJsonDocument document(1536);
  const bool wifiConnected = WiFi.status() == WL_CONNECTED;
  const bool lanConnected = lanHasIp;

  document["activeInterface"] = lanConnected && wifiConnected ? "Wi-Fi + LAN" :
                                lanConnected ? "LAN W5500" :
                                wifiConnected ? "Wi-Fi" : "Offline";
  document["activeIp"] = lanConnected && wifiConnected ?
      WiFi.localIP().toString() + " / " + ETH.localIP().toString() :
      lanConnected ? ETH.localIP().toString() :
      wifiConnected ? WiFi.localIP().toString() : "—";
  document["wifiConnected"] = wifiConnected;
  document["wifiStandby"] = false;
  document["wifiIp"] = wifiConnected ? WiFi.localIP().toString() :
                       settings.wifiIp.toString();
  document["lanConnected"] = lanConnected;
  document["lanIp"] = lanConnected ? ETH.localIP().toString() :
                     settings.lanIp.toString();
  document["queueCount"] = queueCount;
  document["printCount"] = printCount;
  document["paperAvailable"] = paperAvailable();
  document["lastPrintState"] = lastPrintState;
  document["lastPrintError"] = lastPrintError;
  document["lastRecipeName"] = lastRecipeName;
  document["lastTarget"] = lastTarget;
  document["lastActual"] = lastActual;
  document["storageReady"] = storageReady;
  document["uptime"] = millis() / 1000;
  document["bandwidthBps"] = currentBandwidthBps;
  document["peakBandwidthBps"] = peakBandwidthBps;
  document["totalMqttBytes"] = totalMqttBytes;
  JsonArray hourly = document["hourlyPrints"].to<JsonArray>();
  for (uint8_t hour = 0; hour < 24; ++hour) hourly.add(hourlyPrints[hour]);
  document["settings"]["ssid"] = settings.ssid;
  document["settings"]["wifiIp"] = settings.wifiIp.toString();
  document["settings"]["lanIp"] = settings.lanIp.toString();
  document["settings"]["gateway"] = settings.gateway.toString();
  document["settings"]["subnet"] = settings.subnet.toString();

  String response;
  serializeJson(document, response);
  webServer.send(200, "application/json", response);
}

void sendDeviceLogs() {
  String response;
  response.reserve(logCount * 80);
  const size_t first = (logHead + Config::LOG_CAPACITY - logCount) %
                       Config::LOG_CAPACITY;
  for (size_t i = 0; i < logCount; ++i) {
    response += deviceLogs[(first + i) % Config::LOG_CAPACITY];
    response += '\n';
  }
  webServer.send(200, "text/plain; charset=utf-8", response);
}

void saveNetworkSettings() {
  IPAddress wifiIp, lanIp, gateway, subnet;
  if (!webServer.hasArg("ssid") || webServer.arg("ssid").isEmpty() ||
      !parseIp(webServer.arg("wifiIp"), wifiIp) ||
      !parseIp(webServer.arg("lanIp"), lanIp) ||
      !parseIp(webServer.arg("gateway"), gateway) ||
      !parseIp(webServer.arg("subnet"), subnet)) {
    webServer.send(400, "text/plain", "Data tidak lengkap atau format IP salah.");
    return;
  }

  if (wifiIp == lanIp) {
    webServer.send(400, "text/plain",
                   "IP Wi-Fi dan IP LAN harus berbeda agar keduanya aktif bersamaan.");
    return;
  }

  preferences.putString("ssid", webServer.arg("ssid"));
  if (webServer.hasArg("password") && !webServer.arg("password").isEmpty()) {
    preferences.putString("wifi-pass", webServer.arg("password"));
  }
  preferences.putString("wifi-ip", wifiIp.toString());
  preferences.putString("lan-ip", lanIp.toString());
  preferences.putString("gateway", gateway.toString());
  preferences.putString("subnet", subnet.toString());
  addLog("Konfigurasi jaringan disimpan dari dashboard");
  webServer.send(200, "text/plain", "Tersimpan. ESP32 akan restart...");
  delay(800);
  ESP.restart();
}

void initializeDashboard() {
  webServer.on("/", HTTP_GET, []() {
    webServer.send_P(200, "text/html; charset=utf-8", DASHBOARD_HTML);
  });
  webServer.on("/api/status", HTTP_GET, sendStatusJson);
  webServer.on("/api/logs", HTTP_GET, sendDeviceLogs);
  webServer.on("/api/logs", HTTP_DELETE, []() {
    for (String &line : deviceLogs) line = String();
    logHead = 0;
    logCount = 0;
    addLog("Log dashboard dibersihkan");
    webServer.send(200, "text/plain", "OK");
  });
  webServer.on("/api/settings", HTTP_POST, saveNetworkSettings);
  webServer.on("/prints.csv", HTTP_GET, []() {
    if (!storageReady || !LittleFS.exists("/prints.csv")) {
      webServer.send(404, "text/plain", "CSV belum tersedia.");
      return;
    }
    File file = LittleFS.open("/prints.csv", FILE_READ);
    webServer.sendHeader("Content-Disposition",
                         "attachment; filename=printer-base-mmi.csv");
    webServer.streamFile(file, "text/csv");
    file.close();
  });
  webServer.onNotFound([]() {
    webServer.send(404, "application/json", "{\"error\":\"Not found\"}");
  });
  webServer.begin();
  addLog("Dashboard aktif di http://%s", settings.wifiIp.toString().c_str());
}

void setup() {
  Serial.begin(Config::SERIAL_BAUD_RATE);
  loadSettings();
  initializeStorage();
  printerSerial.begin(Config::PRINTER_BAUD_RATE, SERIAL_8N1,
                      Config::PRINTER_RX_PIN, Config::PRINTER_TX_PIN);

  pinMode(Config::WIFI_LED_PIN, OUTPUT);
  digitalWrite(Config::WIFI_LED_PIN, LOW);

  WiFi.mode(WIFI_STA);
  if (!WiFi.config(settings.wifiIp, settings.gateway, settings.subnet,
                   settings.primaryDns, settings.secondaryDns)) {
    Serial.println(F("Gagal mengatur IP statis."));
  }

  initializeEthernet();
  connectWifi();
  configTime(7 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  broker.init(Config::MQTT_PORT);
  initializeDashboard();
  Serial.println(F("MQTT broker aktif pada Wi-Fi dan LAN, port 1883."));
}

void loop() {
  broker.update();
  webServer.handleClient();

  const unsigned long now = millis();
  updateWifiConnection(now);
  updateWifiLed(now);
  updateBandwidth(now);
  processPrintQueue(now);

  delay(10);
}
