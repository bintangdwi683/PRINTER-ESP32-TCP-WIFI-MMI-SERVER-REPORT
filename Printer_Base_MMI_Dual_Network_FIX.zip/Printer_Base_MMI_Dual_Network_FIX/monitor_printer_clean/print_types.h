#pragma once

// Dideklarasikan di header agar Arduino preprocessor mengenali tipe ini saat
// membuat prototype fungsi otomatis sebelum isi sketch.
enum class PrintResult { Printed, RetryLater, Invalid };
